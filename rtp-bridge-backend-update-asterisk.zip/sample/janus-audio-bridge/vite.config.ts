import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()],
  define: {
    process: {
      env: {
        VITE_API_URL: "http://localhost:9501",
      },
    },
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    host: "0.0.0.0",
    port: 3000,
    proxy: {
      "/api": {
        target: "http://localhost:8000",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ""),
      },
      "/janus": {
        target: "http://localhost:8088",
        changeOrigin: true,
        ws: true,
        rewrite: (path) => path.replace(/^\/janus/, ""),
      },
      "/ws": {
        target: "ws://localhost:8088",
        ws: true,
      },
    },
  },
});
